import pandas as pd

# Fonte: https://www.kaggle.com/datasets/oddrationale/mnist-in-csv

# Treino
df_train = pd.read_csv("Example/datasets/Mnist/mnist_train.csv")
cols = df_train.columns.tolist()
cols_new_order = cols[1:] + [cols[0]]
df_train = df_train[cols_new_order]
df_train.to_csv("Example/datasets/Mnist/train.csv", index=False, header=False)

# Teste
df_test = pd.read_csv("Example/datasets/Mnist/mnist_test.csv")
cols = df_test.columns.tolist()
cols_new_order = cols[1:] + [cols[0]]
df_test = df_test[cols_new_order]
df_test.to_csv("Example/datasets/Mnist/test.csv", index=False, header=False)